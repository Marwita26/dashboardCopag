"""COPAG Logistics Analytics - Streamlit dashboard.

Run with:  streamlit run app.py
"""
import matplotlib.pyplot as plt
import pandas as pd
import pydeck as pdk
import streamlit as st

from src import auth, charts
from src.data_cleaning import load_and_clean
from src.filters import apply_filters
from src.kpis import build_insights, compute_kpis
from src.styles import hero, inject_css, kpi_card, section

st.set_page_config(page_title="COPAG Logistics", page_icon="🚚", layout="wide")
inject_css()


@st.cache_data(show_spinner="Loading and cleaning data...")
def get_data():
    return load_and_clean()


def show(fig):
    """Render a Matplotlib figure and free memory."""
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)


def kpi_row(k):
    cols = st.columns(5)
    items = [
        ("Shipments", f"{k['shipments']:,}", f"{k['total_tons']:,.0f} tons moved"),
        ("On-Time Rate", f"{k['on_time_rate']:.1f}%", "deliveries on schedule"),
        ("Avg Cost", f"{k['avg_cost']:,.0f} MAD", f"{k['total_cost']/1e6:.2f} M MAD total"),
        ("Fuel / Ship", f"{k['avg_fuel']:.1f} L", f"avg speed {k['avg_speed']:.0f} km/h"),
        ("CO₂ / Ship", f"{k['avg_co2']:.1f} kg", f"cold-chain breaches {k['breach_rate']:.1f}%"),
    ]
    for col, (label, value, sub) in zip(cols, items):
        with col:
            kpi_card(label, value, sub)


def dashboard():
    df_all, report = get_data()

    # ---- Sidebar ----
    st.sidebar.markdown("## 🚚 COPAG")
    st.sidebar.caption("Logistics & Transport Analytics")
    st.sidebar.markdown("---")
    fdf = apply_filters(df_all)
    st.sidebar.markdown("---")
    st.sidebar.caption(f"Signed in as **{auth.USERNAME}**")
    if st.sidebar.button("Sign out", use_container_width=True):
        auth.logout()
        st.rerun()

    hero("COPAG Logistics Dashboard",
         "Monitor deliveries, delays, costs, fuel and CO₂ across Morocco")

    if fdf.empty:
        st.warning("No shipment matches the selected filters. Please widen your selection.")
        st.stop()

    k = compute_kpis(fdf)
    kpi_row(k)

    tab_over, tab_perf, tab_cost, tab_cold, tab_map, tab_data = st.tabs(
        ["📊 Overview", "⏱️ Performance", "💰 Costs & Emissions", "❄️ Cold Chain & Fleet", "🗺️ Maps", "🗂️ Data"]
    )

    # ---------------- Overview ----------------
    with tab_over:
        section("Performance & routes")
        c1, c2 = st.columns(2)
        with c1:
            show(charts.on_time_over_time(fdf))
        with c2:
            show(charts.top_lanes(fdf))
        section("Key insights")
        for line in build_insights(fdf):
            st.markdown(f'<div class="insight">{line}</div>', unsafe_allow_html=True)

    # ---------------- Performance ----------------
    with tab_perf:
        section("Delays & correlations")
        c1, c2 = st.columns(2)
        with c1:
            show(charts.delay_boxplot(fdf))
        with c2:
            show(charts.correlation_heatmap(fdf))
        c3, c4 = st.columns(2)
        with c3:
            show(charts.delay_histogram(fdf))
        with c4:
            show(charts.delay_by_region(fdf))

    # ---------------- Costs & emissions ----------------
    with tab_cost:
        section("Costs & distribution")
        c1, c2 = st.columns(2)
        with c1:
            show(charts.cost_per_km_by_region(fdf))
        with c2:
            show(charts.product_pie(fdf))
        section("Distance vs cost, fuel and CO₂")
        c3, c4, c5 = st.columns(3)
        with c3:
            show(charts.scatter_distance(fdf, "cost_mad", "Distance vs Cost", "Cost (MAD)"))
        with c4:
            show(charts.scatter_distance(fdf, "fuel_liters", "Distance vs Fuel", "Fuel (L)"))
        with c5:
            show(charts.scatter_distance(fdf, "co2_kg", "Distance vs CO₂", "CO₂ (kg)"))
        c6, c7 = st.columns(2)
        with c6:
            show(charts.cost_by_product(fdf))
        with c7:
            show(charts.monthly_trend(fdf))

    # ---------------- Cold chain & fleet ----------------
    with tab_cold:
        c1, c2 = st.columns(2)
        with c1:
            show(charts.breach_by_product(fdf))
        with c2:
            show(charts.capacity_by_mode(fdf))
        show(charts.speed_by_mode(fdf))

    # ---------------- Maps ----------------
    with tab_map:
        section("Fleet current positions")
        st.map(fdf[["lat", "lon"]].dropna(), latitude="lat", longitude="lon", size=2000, color="#0E7C66")

        section("Route flows between hubs and cities")
        flows = (
            fdf.groupby(["origin_hub", "destination_city", "o_lat", "o_lon", "d_lat", "d_lon"], as_index=False)
            .size()
            .rename(columns={"size": "count"})
        )
        flows["width"] = 1 + flows["count"] / flows["count"].max() * 8
        arcs = pdk.Layer(
            "ArcLayer", data=flows,
            get_source_position=["o_lon", "o_lat"], get_target_position=["d_lon", "d_lat"],
            get_width="width", get_source_color=[14, 124, 102, 180], get_target_color=[245, 158, 11, 180],
            pickable=True,
        )
        view = pdk.ViewState(latitude=31.5, longitude=-8.0, zoom=4.6, pitch=30)
        st.pydeck_chart(
            pdk.Deck(layers=[arcs], initial_view_state=view,
                     tooltip={"text": "{origin_hub} → {destination_city}\n{count} shipments"}),
            use_container_width=True,
        )

    # ---------------- Data ----------------
    with tab_data:
        section("Data cleaning report")
        st.dataframe(pd.DataFrame(report, columns=["Step", "Rows"]), hide_index=True, use_container_width=True)
        section("Filtered data")
        st.dataframe(fdf.drop(columns=["month"]), use_container_width=True, height=380)
        st.download_button("⬇️ Download filtered data (CSV)",
                           fdf.to_csv(index=False).encode("utf-8"),
                           file_name="copag_filtered.csv", mime="text/csv")


if auth.is_authenticated():
    dashboard()
else:
    auth.login_page()
