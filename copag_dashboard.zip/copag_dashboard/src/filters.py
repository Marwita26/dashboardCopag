"""Step 5 - Sidebar filters."""
import pandas as pd
import streamlit as st

ALL = "All"


def _options(series: pd.Series):
    return [ALL] + sorted(series.dropna().unique().tolist())


def apply_filters(df: pd.DataFrame) -> pd.DataFrame:
    st.sidebar.markdown("### 🔎 Filters")
    region = st.sidebar.selectbox("Destination region", _options(df["destination_region"]))
    mode = st.sidebar.selectbox("Transport mode", _options(df["mode"]))
    product = st.sidebar.selectbox("Product category", _options(df["product_category"]))

    dmin, dmax = df["date"].min().date(), df["date"].max().date()
    period = st.sidebar.date_input("Period", value=(dmin, dmax), min_value=dmin, max_value=dmax)

    out = df
    if region != ALL:
        out = out[out["destination_region"] == region]
    if mode != ALL:
        out = out[out["mode"] == mode]
    if product != ALL:
        out = out[out["product_category"] == product]

    # date_input returns a single value while the user is still picking the range
    if isinstance(period, (tuple, list)):
        if len(period) == 2:
            start, end = period
        elif len(period) == 1:
            start = end = period[0]
        else:
            start, end = dmin, dmax
    else:
        start = end = period
    out = out[(out["date"].dt.date >= start) & (out["date"].dt.date <= end)]

    st.sidebar.caption(f"{len(out):,} / {len(df):,} shipments selected")
    return out
