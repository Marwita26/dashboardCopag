"""Step 3 - KPIs and automatic insights."""
import pandas as pd


def compute_kpis(df: pd.DataFrame) -> dict:
    return {
        "shipments": len(df),
        "on_time_rate": df["on_time"].mean() * 100,
        "avg_cost": df["cost_mad"].mean(),
        "avg_fuel": df["fuel_liters"].mean(),
        "avg_co2": df["co2_kg"].mean(),
        "total_cost": df["cost_mad"].sum(),
        "avg_speed": df["avg_speed_kmh"].mean(),
        "breach_rate": df["temperature_breach"].mean() * 100,
        "total_tons": df["quantity_tons"].sum(),
    }


def build_insights(df: pd.DataFrame) -> list:
    """Return short written interpretations of the filtered data."""
    out = []
    lane = df["lane"].value_counts()
    out.append(f"**Busiest lane:** {lane.index[0]} with {lane.iloc[0]} shipments.")

    cpk = df.groupby("destination_region")["cost_per_km"].mean().sort_values(ascending=False)
    out.append(f"**Most expensive region per km:** {cpk.index[0]} ({cpk.iloc[0]:.2f} MAD/km), "
               f"vs {cpk.index[-1]} ({cpk.iloc[-1]:.2f} MAD/km) for the cheapest.")

    ot = df.groupby("destination_region")["on_time"].mean().sort_values()
    out.append(f"**Weakest punctuality:** {ot.index[0]} ({ot.iloc[0]*100:.1f}% on time).")

    pb = df.groupby("product_category")["temperature_breach"].mean().sort_values(ascending=False)
    if pb.iloc[0] > 0:
        out.append(f"**Highest cold-chain breach rate:** {pb.index[0]} ({pb.iloc[0]*100:.1f}%).")
    else:
        out.append("**Cold chain:** no temperature breach in the selected data.")

    pdl = df.groupby("product_category")["delay_min"].mean().sort_values(ascending=False)
    out.append(f"**Product with the longest average delay:** {pdl.index[0]} ({pdl.iloc[0]:.1f} min).")

    co2 = df.groupby("origin_hub")["co2_kg"].mean().sort_values(ascending=False)
    out.append(f"**Highest CO₂ per trip by hub:** {co2.index[0]} ({co2.iloc[0]:.0f} kg).")
    return out
