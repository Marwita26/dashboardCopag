"""Modern look & feel (custom CSS)."""
import streamlit as st

CSS = """
<style>
#MainMenu, footer {visibility: hidden;}
.block-container {padding-top: 1.6rem; max-width: 1280px;}
.hero {background: linear-gradient(120deg,#0E7C66 0%,#14B8A6 100%); color:#fff; padding:1.4rem 1.8rem;
       border-radius:18px; margin-bottom:1.2rem; box-shadow:0 6px 20px rgba(14,124,102,.25);}
.hero h1 {margin:0; font-size:1.8rem; color:#fff;}
.hero p {margin:.2rem 0 0; opacity:.9;}
.kpi {background:#fff; border:1px solid #E2ECE9; border-radius:16px; padding:1rem 1.1rem;
      box-shadow:0 2px 8px rgba(18,51,43,.06); height:100%;}
.kpi .label {font-size:.75rem; color:#64748B; text-transform:uppercase; letter-spacing:.04em; font-weight:600;}
.kpi .value {font-size:1.6rem; font-weight:700; color:#0E7C66; line-height:1.25;}
.kpi .sub {font-size:.75rem; color:#94A3B8;}
.section-title {font-size:1.05rem; font-weight:700; color:#12332B; margin:1.2rem 0 .4rem;}
.insight {background:#F1F6F4; border-left:4px solid #0E7C66; padding:.6rem .9rem; border-radius:8px; margin-bottom:.5rem;}
.login-card {text-align:center; margin-top:5vh; margin-bottom:1rem;}
.login-card h1 {color:#0E7C66; margin:.2rem 0;}
.login-card p {color:#64748B;}
.login-logo {font-size:3rem;}
div[data-testid="stTabs"] button {font-weight:600;}
</style>
"""


def inject_css():
    st.markdown(CSS, unsafe_allow_html=True)


def hero(title: str, subtitle: str):
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def kpi_card(label: str, value: str, sub: str = ""):
    st.markdown(
        f'<div class="kpi"><div class="label">{label}</div><div class="value">{value}</div>'
        f'<div class="sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def section(title: str):
    st.markdown(f'<div class="section-title">{title}</div>', unsafe_allow_html=True)
