"""Step 1 - Data loading and cleaning."""
from pathlib import Path

import pandas as pd

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "copag_logistics.csv"

NUMERIC_COLS = [
    "o_lat", "o_lon", "d_lat", "d_lon", "distance_km", "planned_duration_min",
    "actual_duration_min", "delay_min", "on_time", "temperature_breach",
    "capacity_utilization", "fuel_liters", "co2_kg", "cost_mad", "quantity_tons", "lat", "lon",
]
TEXT_COLS = [
    "shipment_id", "origin_hub", "origin_region", "destination_city",
    "destination_region", "mode", "product_category", "temperature_req",
]


def clean_data(raw: pd.DataFrame):
    """Clean the raw dataframe. Returns (clean_df, report) where report is a list of (step, count)."""
    df = raw.copy()
    report = [("Raw rows loaded", len(df))]

    # 1. Text columns: trim spaces
    for c in TEXT_COLS:
        df[c] = df[c].astype(str).str.strip()

    # 2. Types
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in NUMERIC_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # 3. Duplicates
    n = len(df)
    df = df.drop_duplicates(subset="shipment_id")
    report.append(("Duplicate shipments removed", n - len(df)))

    # 4. Missing critical values
    critical = ["date", "origin_hub", "destination_city", "destination_region", "distance_km",
                "on_time", "mode", "product_category", "cost_mad", "fuel_liters", "co2_kg"]
    n = len(df)
    df = df.dropna(subset=critical)
    report.append(("Rows with missing critical values removed", n - len(df)))

    # 5. Impossible values (negative / zero durations, non-positive distance or cost)
    n = len(df)
    valid = (
        (df["actual_duration_min"] > 0)
        & (df["planned_duration_min"] > 0)
        & (df["distance_km"] > 0)
        & (df["cost_mad"] > 0)
    )
    df = df[valid].copy()
    report.append(("Rows with impossible values removed (duration <= 0, ...)", n - len(df)))

    # 6. Binary columns as int
    for c in ["on_time", "temperature_breach"]:
        df[c] = df[c].round().clip(0, 1).astype(int)

    # 7. Derived features
    df["lane"] = df["origin_hub"] + " → " + df["destination_city"]
    df["cost_per_km"] = df["cost_mad"] / df["distance_km"]
    df["avg_speed_kmh"] = df["distance_km"] / (df["actual_duration_min"] / 60)
    df["fuel_per_100km"] = df["fuel_liters"] / df["distance_km"] * 100
    df["co2_per_km"] = df["co2_kg"] / df["distance_km"]
    df["month"] = df["date"].dt.to_period("M").dt.to_timestamp()

    # 8. Flag (do not delete) cost-per-km statistical outliers
    q1, q3 = df["cost_per_km"].quantile([0.25, 0.75])
    iqr = q3 - q1
    df["cost_outlier"] = (df["cost_per_km"] > q3 + 3 * iqr) | (df["cost_per_km"] < q1 - 3 * iqr)
    report.append(("Cost/km outliers flagged (kept in data)", int(df["cost_outlier"].sum())))

    df = df.sort_values("date").reset_index(drop=True)
    report.append(("Clean rows available for analysis", len(df)))
    return df, report


def load_and_clean(path: Path = DATA_PATH):
    raw = pd.read_csv(path)
    return clean_data(raw)
