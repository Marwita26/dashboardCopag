"""Step 2 - Visualizations (Matplotlib + Seaborn). Every function returns a Figure."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

GREEN, TEAL, ORANGE, RED = "#0E7C66", "#14B8A6", "#F59E0B", "#DC2626"
PALETTE = ["#0E7C66", "#14B8A6", "#F59E0B", "#3B82F6", "#8B5CF6", "#EC4899", "#64748B"]

sns.set_theme(style="whitegrid", palette=PALETTE)
plt.rcParams.update({
    "axes.titlesize": 13, "axes.titleweight": "bold", "axes.labelsize": 10,
    "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 110,
})


def _fig(w=7, h=4):
    fig, ax = plt.subplots(figsize=(w, h))
    return fig, ax


def _rotate(ax):
    plt.setp(ax.get_xticklabels(), rotation=40, ha="right", fontsize=8)


def on_time_over_time(df):
    d = df.groupby("date", as_index=False)["on_time"].mean()
    d["rate"] = d["on_time"] * 100
    d["smooth"] = d["rate"].rolling(14, min_periods=1).mean()
    fig, ax = _fig()
    ax.plot(d["date"], d["rate"], color=TEAL, alpha=0.35, lw=1, label="Daily")
    ax.plot(d["date"], d["smooth"], color=GREEN, lw=2.2, label="14-day average")
    ax.axhline(df["on_time"].mean() * 100, color=ORANGE, ls="--", lw=1, label="Overall average")
    ax.set(title="Daily On-Time Performance", xlabel="Date", ylabel="On-time rate (%)", ylim=(0, 105))
    ax.legend(frameon=False, fontsize=8)
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def top_lanes(df, n=10):
    t = df["lane"].value_counts().head(n).reset_index()
    t.columns = ["lane", "count"]
    fig, ax = _fig()
    sns.barplot(data=t, x="count", y="lane", color=GREEN, ax=ax)
    ax.bar_label(ax.containers[0], padding=3, fontsize=8)
    ax.set(title="Top 10 Routes by Volume", xlabel="Number of shipments", ylabel="")
    fig.tight_layout()
    return fig


def delay_boxplot(df):
    fig, ax = _fig()
    sns.boxplot(data=df, x="delay_min", y="product_category", color=TEAL, fliersize=2, ax=ax)
    ax.axvline(0, color=RED, ls="--", lw=1)
    ax.set(title="Delivery Delay by Product Type", xlabel="Delay (min)", ylabel="")
    fig.tight_layout()
    return fig


def correlation_heatmap(df):
    cols = ["distance_km", "planned_duration_min", "actual_duration_min", "delay_min", "on_time",
            "temperature_breach", "capacity_utilization", "fuel_liters", "co2_kg", "cost_mad", "quantity_tons"]
    fig, ax = _fig(7, 5.2)
    sns.heatmap(df[cols].corr(), annot=True, fmt=".2f", cmap="RdYlGn", center=0,
                annot_kws={"size": 7}, cbar_kws={"shrink": 0.8}, ax=ax)
    ax.set_title("Correlation Heatmap")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", fontsize=8)
    plt.setp(ax.get_yticklabels(), fontsize=8)
    fig.tight_layout()
    return fig


def cost_per_km_by_region(df):
    d = df.groupby("destination_region", as_index=False)["cost_per_km"].mean().sort_values("cost_per_km", ascending=False)
    fig, ax = _fig()
    ax.bar(d["destination_region"], d["cost_per_km"], color=GREEN)
    ax.bar_label(ax.containers[0], fmt="%.1f", fontsize=8, padding=2)
    ax.set(title="Average Cost per km by Region", xlabel="", ylabel="MAD / km")
    _rotate(ax)
    fig.tight_layout()
    return fig


def product_pie(df):
    c = df["product_category"].value_counts()
    fig, ax = _fig(6, 4.5)
    ax.pie(c.values, labels=c.index, autopct="%1.1f%%", startangle=90, colors=PALETTE,
           wedgeprops={"width": 0.45, "edgecolor": "white"}, textprops={"fontsize": 8})
    ax.set_title("Shipment Share by Product")
    ax.axis("equal")
    fig.tight_layout()
    return fig


def delay_histogram(df):
    fig, ax = _fig()
    sns.histplot(df["delay_min"], bins=30, color=TEAL, kde=True, ax=ax)
    ax.axvline(0, color=RED, ls="--", lw=1)
    ax.set(title="Delay Distribution", xlabel="Delay (min)", ylabel="Shipments")
    fig.tight_layout()
    return fig


def delay_by_region(df):
    d = df.groupby("destination_region", as_index=False)["delay_min"].mean().sort_values("delay_min", ascending=False)
    fig, ax = _fig()
    ax.bar(d["destination_region"], d["delay_min"], color=ORANGE)
    ax.set(title="Average Delay by Region", xlabel="", ylabel="Minutes")
    _rotate(ax)
    fig.tight_layout()
    return fig


def scatter_distance(df, y, title, ylabel):
    fig, ax = _fig()
    sns.scatterplot(data=df, x="distance_km", y=y, hue="mode", alpha=0.6, s=28, ax=ax,
                    palette={"Reefer": GREEN, "Dry Van": ORANGE})
    ax.set(title=title, xlabel="Distance (km)", ylabel=ylabel)
    ax.legend(frameon=False, fontsize=8, title="Mode")
    fig.tight_layout()
    return fig


def cost_by_product(df):
    d = df.groupby("product_category", as_index=False)["cost_mad"].mean().sort_values("cost_mad", ascending=False)
    fig, ax = _fig()
    ax.bar(d["product_category"], d["cost_mad"], color=GREEN)
    ax.set(title="Average Cost by Product", xlabel="", ylabel="MAD")
    _rotate(ax)
    fig.tight_layout()
    return fig


def breach_by_product(df):
    d = df.groupby("product_category", as_index=False)["temperature_breach"].mean()
    d["rate"] = d["temperature_breach"] * 100
    d = d.sort_values("rate", ascending=False)
    fig, ax = _fig()
    ax.bar(d["product_category"], d["rate"], color=RED)
    ax.bar_label(ax.containers[0], fmt="%.1f%%", fontsize=8, padding=2)
    ax.set(title="Temperature Breach Rate by Product", xlabel="", ylabel="Breach rate (%)")
    _rotate(ax)
    fig.tight_layout()
    return fig


def capacity_by_mode(df):
    d = df.groupby("mode", as_index=False)["capacity_utilization"].mean()
    fig, ax = _fig(6, 4)
    ax.bar(d["mode"], d["capacity_utilization"] * 100, color=[GREEN, ORANGE][: len(d)], width=0.5)
    ax.bar_label(ax.containers[0], fmt="%.1f%%", fontsize=9, padding=2)
    ax.set(title="Average Capacity Utilization by Transport Mode", xlabel="", ylabel="Utilization (%)", ylim=(0, 100))
    fig.tight_layout()
    return fig


def monthly_trend(df):
    m = df.groupby("month").agg(cost=("cost_mad", "sum"), co2=("co2_kg", "sum")).reset_index()
    fig, ax = _fig()
    ax.bar(m["month"], m["cost"], width=20, color=GREEN, alpha=0.85)
    ax.set(title="Monthly Transport Cost & CO₂", xlabel="", ylabel="Total cost (MAD)")
    ax2 = ax.twinx()
    ax2.plot(m["month"], m["co2"], color=ORANGE, marker="o", lw=2)
    ax2.set_ylabel("Total CO₂ (kg)")
    ax2.grid(False)
    ax2.spines["right"].set_visible(True)
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def speed_by_mode(df):
    fig, ax = _fig()
    sns.violinplot(data=df, x="mode", y="avg_speed_kmh", hue="mode", palette={"Reefer": GREEN, "Dry Van": ORANGE},
                   legend=False, inner="quartile", ax=ax)
    ax.set(title="Average Speed by Transport Mode", xlabel="", ylabel="km/h")
    fig.tight_layout()
    return fig
