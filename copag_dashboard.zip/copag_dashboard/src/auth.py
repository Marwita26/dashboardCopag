"""Login module: single user, password stored as a SHA-256 hash (never in clear text)."""
import hashlib
import hmac

import streamlit as st

USERNAME = "marwa"
# SHA-256 of the password
PASSWORD_HASH = hashlib.sha256("Marwabdf34".encode("utf-8")).hexdigest()
MAX_ATTEMPTS = 5


def _check(username: str, password: str) -> bool:
    user_ok = hmac.compare_digest(username.strip().lower(), USERNAME)
    pwd_hash = hashlib.sha256(password.encode("utf-8")).hexdigest()
    pwd_ok = hmac.compare_digest(pwd_hash, PASSWORD_HASH)
    return user_ok and pwd_ok


def is_authenticated() -> bool:
    return st.session_state.get("authenticated", False)


def logout() -> None:
    st.session_state["authenticated"] = False
    st.session_state["attempts"] = 0


def login_page() -> None:
    """Render the login form. Sets session_state['authenticated'] on success."""
    st.session_state.setdefault("attempts", 0)

    _, center, _ = st.columns([1, 1.2, 1])
    with center:
        st.markdown(
            """
            <div class="login-card">
                <div class="login-logo">🚚</div>
                <h1>COPAG Logistics</h1>
                <p>Sign in to access the analytics dashboard</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        locked = st.session_state["attempts"] >= MAX_ATTEMPTS
        with st.form("login_form"):
            username = st.text_input("Username", placeholder="Enter your username")
            password = st.text_input("Password", type="password", placeholder="Enter your password")
            submitted = st.form_submit_button("Sign in", use_container_width=True, disabled=locked)

        if submitted:
            if _check(username, password):
                st.session_state["authenticated"] = True
                st.session_state["attempts"] = 0
                st.rerun()
            else:
                st.session_state["attempts"] += 1
                left = MAX_ATTEMPTS - st.session_state["attempts"]
                st.error("Invalid username or password." + (f" {left} attempt(s) left." if left > 0 else ""))
        if locked:
            st.warning("Too many failed attempts. Refresh the page to try again.")
