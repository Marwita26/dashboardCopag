# COPAG Logistics Dashboard

Streamlit dashboard to analyse COPAG shipments across Morocco (delays, costs, fuel, CO₂, cold chain).

## Run
```bash
python -m venv venv && source venv/bin/activate    # Windows: venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Login
Username: `marwa` - the password is stored as a SHA-256 hash in `src/auth.py` (change `USERNAME` / `PASSWORD_HASH` there).

## Structure
| File | Role |
|---|---|
| `app.py` | Main app: login gate, KPIs, tabs, maps |
| `src/auth.py` | Login / logout |
| `src/data_cleaning.py` | Step 1 - cleaning + derived columns (speed, cost/km, ...) |
| `src/charts.py` | Step 2 - Matplotlib / Seaborn charts |
| `src/kpis.py` | Step 3 - KPIs and automatic insights |
| `src/filters.py` | Sidebar filters (region, mode, product, period) |
| `src/styles.py` | Modern CSS theme |
| `data/copag_logistics.csv` | Dataset |

## Cleaning rules
Trim text, parse dates, drop duplicate `shipment_id`, drop rows with missing critical values,
drop impossible rows (actual duration <= 0), cast binary columns, add `lane`, `cost_per_km`,
`avg_speed_kmh`, `fuel_per_100km`, `co2_per_km`, flag cost/km outliers (kept).
